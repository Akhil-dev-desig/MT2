import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ListTodoComponent } from './components/list-todo/list-todo.component';
import { EditTodoComponent } from './components/edit-todo/edit-todo.component';
import { AddTodoComponent } from './components/add-todo/add-todo.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"login",component:LoginComponent},
  {path:"list-todo",component:ListTodoComponent},
  {path:"edit-todo/:id",component:EditTodoComponent},
  {path:"add-todo",component:AddTodoComponent},
  {path:"",component:HomeComponent},
  {path:"**",component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
