import { Component, OnInit } from '@angular/core';
import { TodoServicesService } from 'src/app/services/todoservices.service';
import { FormBuilder, Validators,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']
})
export class AddTodoComponent implements OnInit {
  addForm: any;
  submitted: boolean;

  constructor(private todoService: TodoServicesService,private formBuilder: FormBuilder ,
      private router:Router ) { }

  ngOnInit() {
    this.addForm =this.formBuilder.group({
      id:[],
      todoName: ['', Validators.required],
      todoStatus: ['', Validators.required],
    })
  }
  onSubmit() {

    this.submitted = true;
    //if validation fails it should return to validate again
    if (this.addForm.invalid) {
      return;
    }
    console.log(this.addForm.value);
    this.todoService.createTodo(this.addForm.value).subscribe(data => {
      alert(this.addForm.controls.firstName.value + ' record id added successfully..!');
      this.router.navigate(['list-todo']);
    })
  }
}
