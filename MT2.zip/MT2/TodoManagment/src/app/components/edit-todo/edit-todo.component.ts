import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/model/todo.model';

import { TodoServicesService } from 'src/app/services/todoservices.service'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-edit-todo',
  templateUrl: './edit-todo.component.html',
  styleUrls: ['./edit-todo.component.css']
})
export class EditTodoComponent implements OnInit {
  todoId: string;
  editForm:FormGroup;
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute ,
    private todoService: TodoServicesService) {

    this.route.params.subscribe(params => this.todoId = params['id']);

    console.log(this.todoId);
  }



ngOnInit() {
  if (this.todoId != null) {
    if (!this.todoId) {
      alert('Invalid Action');
      this.router.navigate(['todo-list']);
      return;
    }
  
    this.editForm = this.formBuilder.group({
      id: [],

      todoName: ['', Validators.required],
      todoStatus: ['', Validators.required]

    });
    //pulling data from databse or json server using service 
  
    this.todoService.getTodosById(+this.todoId).subscribe(data => {
      this.editForm.setValue(data)
    });
  }
  else {
    this.router.navigate(['/login']);
  }
}

}