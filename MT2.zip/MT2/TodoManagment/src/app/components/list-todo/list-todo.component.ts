import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/model/todo.model';
import { Router } from '@angular/router';
import { TodoServicesService } from 'src/app/services/todoservices.service'

@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit {
  todos: Todo[]
  constructor(private router: Router, private todoService: TodoServicesService) { }

  //DELETE todo
  deleteTodo(todo: Todo): void {
    let result = confirm("Do you want  to delete todo?");
    if (result)
      this.todoService.deleteTodo(todo.id).subscribe(data => {
        this.todos = this.todos.filter(u => u !== todo);
      })
    alert(`${todo.todoName} record is deleted..!`);
  }
  //add new todo
  addTask(): void {
    this.router.navigate(['add-todo']);
  }

  //modify todo
  editTodo(todo: Todo): void {

    this.router.navigate(['edit-todo', todo.id.toString()]);

  }

  ngOnInit() {
  //    if(localStorage.getItem("todoname")!=null){
       this.todoService.getTodos().subscribe(data =>{this.todos=data});
  //   }
  //    else{
  //     this.router.navigate(['/login']);
  //    }
  // }
//
}
}
