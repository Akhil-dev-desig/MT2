import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private formBulider: FormBuilder, private router: Router) { }
 //instance variables--by default public in ts
 loginForm: FormGroup;
 submitted: boolean = false;
 invalidLogin: boolean = false;


  ngOnInit() {
    this.loginForm = this.formBulider.group({
      email: ['', Validators.required], 
      password: ['', Validators.required]
      //nested validations
    });
  }
   //this will be exceted after clicking on login button
   onSubmit() {

    this.submitted = true;
    //if validation fails it should return to validate again
    if (this.loginForm.invalid) {
      return;
    }

    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;

    if (username == "harika@gmail.com" && password == "12345") {

      localStorage.setItem("username", username);
      this.router.navigate(['list-todo']);
    }
    else {
      this.invalidLogin = true;
    }
  }

}
