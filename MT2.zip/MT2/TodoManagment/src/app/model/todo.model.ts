export class Todo{
    id:number;
    todoName:string;
    todoStatus:string;
}