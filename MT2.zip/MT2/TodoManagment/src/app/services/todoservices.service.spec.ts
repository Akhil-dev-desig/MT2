import { TestBed } from '@angular/core/testing';

import { Todo.ServicesService } from './todoservices.service';

describe('Todo.ServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Todo.ServicesService = TestBed.get(Todo.ServicesService);
    expect(service).toBeTruthy();
  });
});
