import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from 'src/app/model/todo.model';
@Injectable({
  providedIn: 'root'
})
export class TodoServicesService {

  

  constructor(private http: HttpClient) { }
  baseUrl: string = "http://localhost:3000/todos";
  //get all todos
  getTodos() {
    return this.http.get<Todo[]>(this.baseUrl);
  }
  //get all todos by id
  getTodosById(id: number) {
    return this.http.get<Todo>(this.baseUrl + "/" + id);
  }
  //add todo
  createTodo(todo: Todo) {
    return this.http.post(this.baseUrl, todo);

  }
  //modify user
  updateTodo(todo: Todo) {
    return this.http.put(this.baseUrl + "/" + todo.id, todo);
  }
  //delete users by id
  deleteTodo(id: number) {
    return this.http.delete(this.baseUrl + "/" + id);
  }
}

